# -*- coding: utf-8 -*-

from pyrevit import revit, DB, UI
import clr
clr.AddReference('System.Collections')
from System.Collections.Generic import List
import os

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document
uiapp = __revit__.Application

active_view = uidoc.ActiveView

def capture_view_as_image(doc, view):
    img_export_options = DB.ImageExportOptions()
    img_export_options.ExportRange = DB.ExportRange.SetOfViews
    img_export_options.FilePath = "C:/ve_view.jpg"
    img_export_options.HLRandWFViewsFileType = DB.ImageFileType.JPEGLossless
    img_export_options.ImageResolution = DB.ImageResolution.DPI_300
    img_export_options.ZoomType = DB.ZoomFitType.FitToPage
    img_export_options.FitDirection = DB.FitDirectionType.Horizontal
    img_export_options.ImageResolution = DB.ImageResolution.DPI_150

    # Ensure the directory exists
    directory = os.path.dirname(img_export_options.FilePath)
    if not os.path.exists(directory):
        os.makedirs(directory)

    view_id_list = List[DB.ElementId]()
    view_id_list.Add(view.Id)
    img_export_options.SetViewsAndSheets(view_id_list)

    # Print the view ID list for debugging
    print("View ID list for export: {}".format([vid.IntegerValue for vid in view_id_list]))

    try:
        doc.ExportImage(img_export_options)
        print("Image exported successfully.")
    except Exception as e:
        print("Failed to export image: {}".format(e))

with revit.Transaction('Capture View Image'):
    capture_view_as_image(doc, active_view)
